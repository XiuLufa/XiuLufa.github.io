# my first project

**This is my first project using html and css**
![first project view](https://github.com/user-attachments/assets/34ea6c0c-8fe7-41ed-97c8-47d00cea1fb6)

- [Demo Project](https://code-banu.github.io/my-first-project/)

- Developed by Raheleh Banam

- Created - 2024-10-6

- Technologies Used - Html , css 

- Hooks Used : useState 

- Role - Frontend

- How to reach me : with my [instagram](https://www.instagram.com/code_banu?igsh=MXdzZm9ucG1tODF0Yg==) and [linkedin](https://www.linkedin.com/in/raheleh-banam-344287230)
